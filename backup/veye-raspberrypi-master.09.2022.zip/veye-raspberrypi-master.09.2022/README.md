# raspberrypi
VEYE camera module software on RaspberryPi

# wiki：
[VEYE-MIPI-290/327](http://wiki.veye.cc/index.php/VEYE-MIPI-290/327_index)

[CS-MIPI-IMX307](http://wiki.veye.cc/index.php/CS-MIPI-IMX307_STARVIS_Module_index)

Software toolkits contains three parts. veye_raspcam is raspcam alike Video Stream Toolkits, D_mipi_rpi is D-SDK Video Stream Toolkits, i2c_cmd is Video Control Toolkits.

Video Stream Tookkits provides real-time display, capture, video recording, etc.
Video Control Toolkits is a shell script which provides ISP parameters configuration capbility.
Both is Open Source.

# Forum
[forum.veye.cc](http://forum.veye.cc)



