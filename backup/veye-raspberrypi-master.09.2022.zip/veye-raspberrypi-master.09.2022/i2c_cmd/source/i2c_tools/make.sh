
gcc -o i2c_read i2c_read.c strfunc.c 
gcc -o i2c_write i2c_write.c strfunc.c 

